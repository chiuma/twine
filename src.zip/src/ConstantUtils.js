export const ConstantUtils = {
    url: {
     // SVILUPPO
      SERVER_URL1                      : "http://127.0.0.1/react/twine/api/",
      HOME_URL1                : "http://127.0.0.1/react/twine/",
       
    
  // PRODUZIONE
   SERVER_URL                : "https://www.cimicapp.com/temp/twineMobile/api/", 
   HOME_URL                  : "https://www.cimicapp.com/temp/twineMobile/",

   
    }
}
