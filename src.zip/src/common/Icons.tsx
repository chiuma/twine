import ClientiIcon from '@material-ui/icons/People';
import ArticoliIcon from '@material-ui/icons/Bookmarks';
import ColoriIcon from '@material-ui/icons/ColorLens';
import ConsegneIcon from '@material-ui/icons/LocalShipping';
import OrdiniIcon from '@material-ui/icons/Assignment';
import ProvenienzeIcon from '@material-ui/icons/WhatsApp';
import NuovoIcon from '@material-ui/icons/Add';
import HomeIcon from '@material-ui/icons/Home';
import StampaIcon from '@material-ui/icons/PrintRounded';
import GraficiIcon from '@material-ui/icons/BarChart';

import QrCodeIcon from '@material-ui/icons/CropFree';

import SaveIcon from '@material-ui/icons/Save';
export   const IconsMenu = {
    ClientiIcon  ,
    ArticoliIcon,
    ColoriIcon,
    ConsegneIcon,
    OrdiniIcon,
    ProvenienzeIcon,
    NuovoIcon,
    StampaIcon,
    HomeIcon,
    GraficiIcon,
    SaveIcon,
    QrCodeIcon
   
};